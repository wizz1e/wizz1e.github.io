Source code and contacts
========================

Repository and bugs
~~~~~~~~~~~~~~~~~~~

The **source code** for this app is hosted on
https://github.com/frankban/django-endless-pagination.

The **Mercurial repository** of this project is hosted on
https://bitbucket.org/frankban/django-endless-pagination.

To file **bugs and requests**, please use
https://github.com/frankban/django-endless-pagination/issues.

Contacts
~~~~~~~~

Francesco Banconi

- Email: ``frankban at gmail.com``
- IRC: ``frankban@freenode``
